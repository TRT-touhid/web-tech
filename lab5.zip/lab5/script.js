function analyzeText() {
    let text = document.getElementById("textInput").value;

    // Handle empty input
    if (text.trim() === "") {
        document.getElementById("result").innerHTML = "Please enter some text.";
        return;
    }

    // Character count
    let charCount = text.length;

    // Word count (remove extra spaces)
    let words = text.trim().split(/\s+/);
    let wordCount = words.length;

    // Reverse text
    let reversed = text.split("").reverse().join("");

    // Display result
    document.getElementById("result").innerHTML = `
        <p><b>Total Characters:</b> ${charCount}</p>
        <p><b>Total Words:</b> ${wordCount}</p>
        <p><b>Reversed Text:</b> ${reversed}</p>
    `;
}